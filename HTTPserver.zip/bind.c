#include "bind.h"

#include <stdio.h>
#include <signal.h>
#include <string.h>
#include <stdlib.h>
#include <ctype.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <unistd.h>

#include <arpa/inet.h>
#include <err.h>
#include <errno.h>

#define MAXLEN 2049 // To allow for \0 at the end of the string

void create_response_header(int status_code, char *response_string, size_t fileSize) {
    char size_as_str[64];
    sprintf(size_as_str, "%ld", fileSize);

    strcpy(response_string, "HTTP/1.1 ");

    switch (status_code) {
        case 200:
            strcat(response_string, "200 OK\r\n");
            strcat(response_string, "Content-Length:");
            strcat(response_string, size_as_str);
            strcat(response_string, "\r\n\r\n");
            break;
        case 201:
            strcat(response_string, "201 Created\r\n");
            strcat(response_string, "Content-Length: 8");
            strcat(response_string, "\r\n\r\n");
            strcat(response_string, "Created\n");
            break;
        case 400:
            strcat(response_string, "400 Bad Request\r\n");
            strcat(response_string, "Content-Length: 12");
            strcat(response_string, "\r\n\r\n");
            strcat(response_string, "Bad Request\n");
            break;
        case 403:
            strcat(response_string, "403 Forbidden\r\n");
            strcat(response_string, "Content-Length: 10");
            strcat(response_string, "\r\n\r\n");
            strcat(response_string, "Forbidden\n");
            break;
        case 404:
            strcat(response_string, "404 Not Found\r\n");
            strcat(response_string, "Content-Length: 10");
            strcat(response_string, "\r\n\r\n");
            strcat(response_string, "Not Found\n");
            break;
        case 500:
            strcat(response_string, "500 Internal Server Error\r\n");
            strcat(response_string, "Content-Length: 22");
            strcat(response_string, "\r\n\r\n");
            strcat(response_string, "Internal Server Error\n");
            break;
        case 501:
            strcat(response_string, "501 Not Implemented\r\n");
            strcat(response_string, "Content-Length: 16");
            strcat(response_string, "\r\n\r\n");
            strcat(response_string, "Not Implemented\n");
            break;
    }
    
    return;
}

char * read_file_contents(int *status_code, char *fName) {
    struct stat statbuf;

    int fd = open(fName, O_RDONLY);

    if (fd == -1) {
        if (errno == EACCES || errno == EPERM) {
            *status_code = 403;
        } else if (errno == ENOENT) {
            *status_code = 404;
        }
        return NULL;
    }

    // Need to obtain information about the size of the file to allocate
    // buffer to read it. If we are able to open the file, fstat should
    // typically not fail. Adding the check anyway.
    int n = fstat(fd, &statbuf);

    if (n == -1) {
        close(fd);
        return NULL;
    }
    off_t fileSize = statbuf.st_size;

    char *fileContents = (char *) calloc((fileSize+1), sizeof(char));

    read(fd, fileContents, fileSize);
    close(fd);
    return fileContents;
}

int create_listen_socket(uint16_t port) {
    signal(SIGPIPE, SIG_IGN);
    if (port == 0) {
        return -1;
    }
    struct sockaddr_in addr;
    int listenfd = socket(AF_INET, SOCK_STREAM, 0);
    if (listenfd < 0) {
        return -2;
    }
    memset(&addr, 0, sizeof addr);
    addr.sin_family = AF_INET;
    addr.sin_addr.s_addr = htons(INADDR_ANY);
    addr.sin_port = htons(port);
    if (bind(listenfd, (struct sockaddr *) &addr, sizeof addr) < 0) {
        return -3;
    }
    if (listen(listenfd, 500) < 0) {
        return -4;
    }
    return listenfd;
}

void handle_connection(int listenfd) {
FILE *fp = fopen("/tmp/as1.log", "a+");
fprintf(fp, "Inside the handle_connection fn\n");
fclose(fp);
    while(1) {
        char buffer[MAXLEN];
        int bytesRead;

        // accept creates a new socket
        int connfd = accept(listenfd, NULL, NULL);

        // Zero out the buffer
        memset(buffer, 0, MAXLEN);

        // Read from the socket

fopen("/tmp/as1.log", "a+");
fprintf(fp, "Inside the infinite while loop\n");
fclose(fp);
fopen("/tmp/as1.log", "a+");
        bytesRead = read(connfd, buffer, MAXLEN);
        buffer[bytesRead] = '\0';
fprintf(fp, "Buffer contents read from socket = %s\n", buffer);

        char *s = buffer;
        char method[9];
        int i = 0;
        char uri[MAXLEN];
        char response_text[MAXLEN];
        char *fileContents = "";
        int status_code = 200;
        size_t fileSize = 0;

        while (s[i] != ' ') {
            method[i] = s[i];
            i++;
        }
        method[i] = '\0';

        // Can add a check here to check if the next character is "/".
        // Skipping it for now.

        i += 2; // Skip the space and "/" part of the URI
        int j = 0;
        while (s[i] != ' ') {
            uri[j++] = s[i++];
        }
        uri[j] = '\0';
fprintf(fp, "The method = %s and uri = %s\n", method, uri);
fclose(fp);

        if (validate_uri(uri) != 0) {
            status_code = 400;
        } else {
            if (strcmp(method, "GET") == 0) {
                fileContents = read_file_contents(&status_code, uri);

                if (fileContents != NULL) {
                    fileSize = strlen(fileContents);
                }
            } else if (strcmp(method, "PUT") == 0) {
                // For the PUT method, we need to read the message body. This
                // will be present after the following string "\r\n\r\n", but
                // there is useful content before it. In particular, we need to
                // obtain the Content-Length information to allocate memory to
                // read the data to be written.
    
                long content_length;
                while (1) {
                    if (s[i] == 'C') {
                        char *t = s + i;
                        if (strncmp(t, "Content-Length:", 15) == 0) {
                            i += 16; // Move past the ": "
                            char *u = s + i; // First char of the length value
                            j = 0;
                            char content_len_as_str[64]; // Allow space for a really big file
                            while (isdigit(u[j])) {
                                content_len_as_str[j] = u[j];
                                j++;
                            }
                            content_len_as_str[j] = '\0';
                            content_length = strtol(content_len_as_str, NULL, 10);
                            break;
                        }
                    }
                    i++;
                }
                char *msg_body = (char *) calloc(content_length, sizeof(char));
                read(connfd, msg_body, content_length);

                // Create the file. First check if it exists, since the
                // status code will depend on it.
                int fileExists = access(uri, F_OK);

                if (fileExists != 0) { // File does not exist
                    status_code = 201; // This can change if file can't be written
                    fileSize = 8; // For "Created\n"
                } else {
                    fileSize = 3; // default status_code of 200, and str = "OK\n"
                }
                int ofd = open(uri, O_WRONLY|O_CREAT, 0644);
                if (ofd == -1) {
                    if (errno == EACCES) {
                        status_code = 403;
                    }
                } else {
                    write(ofd, msg_body, content_length);
                    close(ofd);
                }
                free(msg_body);
            }
        }

        create_response_header(status_code, response_text, fileSize);

        char *response = (char *) calloc(MAXLEN+fileSize+1, sizeof(char));
        strcpy(response, response_text);

        if (status_code == 200 || status_code == 201) {
            if (strcmp(method, "GET") == 0) {
                strcat(response, fileContents);
            } else if (strcmp(method, "PUT") == 0) {
                strcat(response, "OK\n");
            }
        }

        write(connfd, response, strlen(response));
        close(connfd);

        if (status_code == 200 || status_code == 201) {
            if (strcmp(method, "GET") == 0) {
                free(fileContents);
            }
        }
        free(response);
    }

    return;
}

// A valid URI has the following characteristics
// Starts with the letter "/"
// Consists of letters [a-zA-Z0-9], '.', '_'
//
// Input parameters:
// uri: char *: URI text to validate
// Returns: int: 0 if it meets the requirements, 1 otherwise
int validate_uri(char *uri) {
    int i = 0;

    if (uri[i] == ' ') {
        return 1;
    }

    while (uri[i] != '\0') {
        if (!isalnum(uri[i]) && uri[i] != '_' && uri[i] != '.') {
            return 1;
        }
        i++;
    }

    return 0;
}

// Since 1.1 is the only supported version, the only valid input is
// "HTTP/1.1"
//
// Input parameters:
// version: char *: Version text to validate
// Returns: int: 0 if it meets the requirements, 1 otherwise
int validate_version(char *version) {
    return strcmp(version, "HTTP/1.1");
}
