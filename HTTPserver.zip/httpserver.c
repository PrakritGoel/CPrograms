#include "bind.h"

#include <err.h>
#include <errno.h>
#include <stdio.h>
#include <string.h>
#include <stdlib.h>

// Usage Function
//
// Input parameters:
// exec_name: char *: Name of the program
// Returns: void
void usage(char *exec_name) {
    printf("usage: %s <port>\n", exec_name);
    return;
}

// main function. Receives inputs as command line arguments, and does
// basic validation. Calls the required function for each input file.
//
// Input parameters:
// argc: int: Number of arguments
// argv: char **: Input arguments provided by the user
// Returns: 0 if there are no issues, 1 otherwise
int main(int argc, char **argv) {
    int exit_status = 0;

    // The program accepts a single integer port number as a required argument
    if (argc != 2) {
        warnx("wrong arguments: %s port_num", argv[0]);
        usage(argv[0]);
        return 1;
    }

    char *endPtr = NULL;
    int port_num = strtol(argv[1], &endPtr, 10);

    if (endPtr == argv[1]) {
        warnx("invalid port number: %s", argv[1]);
        return 1;
    } else {
        // Create Socket
        int socket = create_listen_socket(port_num);

        if (socket < 0) {
            warnx("Unable to open socket. Exiting...");
            return 1;
        }

        // Now that the socket has been created, listen on the socket
        // for clients to connect, and take required action.
        while (1) {
            handle_connection(socket);
        }
    }

    return (exit_status);
}
