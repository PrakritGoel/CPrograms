#include "bind.h"
#include <stdio.h>

void test_validate_uri() {
    char* valid_uri = "/ab1Z._ ";
    char* invalid1 = "";
    char* invalid2 = "ab1Z._ ";
    char* invalid3 = "/ab%Z._ ";

    if (validate_uri(valid_uri) != 0) {
        printf("Validate URI test 0 failed\n");
    }
    if (validate_uri(invalid1) != 1) {
        printf("Validate URI test 1 failed\n");
    }
    if (validate_uri(invalid2) != 1) {
        printf("Validate URI test 2 failed\n");
    }
    if (validate_uri(invalid3) != 1) {
        printf("Validate URI test 3 failed\n");
    }
}

void test_validate_version() {
    if (validate_version("HTTP/1.1") != 0) {
        printf("Validate Version test 0 failed\n");
    }
    if (validate_version("HTTP/1.0") == 0) {
        printf("Validate Version test 1 failed\n");
    }
}

int main() {
    test_validate_uri();
    test_validate_version();
}
